package com.company;

public class Main {
    static int n=0;
    static  int array[][]={{8,5,9,2},{4,6,99,4},{-4,54,-86,7},{44,654,-7,2}};
    private static void meth(int k){
        for(int i=0;i<array.length;i++){

            if(k>array[i].length && k<=0)
                throw new IllegalArgumentException();}
        n=k-1;

        for(int i=0;i<array.length;i++){
            for(int j=0;j<array[i].length;j++){
                if(j==n)array[i][j]=0;
            }
        }
        for(int i=0;i<array.length;i++){
            for(int j=0;j<array[i].length;j++)
                System.out.print(array[i][j]+" ");
            System.out.println();
        }
    }
    public static void main(String[] args) {

        meth(1);
    }
}
